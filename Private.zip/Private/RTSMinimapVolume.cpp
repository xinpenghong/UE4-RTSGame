#include "RTSPluginPCH.h"
#include "RTSMinimapVolume.h"


ARTSMinimapVolume::ARTSMinimapVolume(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}
