#include "RTSPluginPCH.h"
#include "RTSResourceType.h"


URTSResourceType::URTSResourceType(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}
