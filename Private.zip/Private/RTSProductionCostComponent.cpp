#include "RTSPluginPCH.h"
#include "RTSProductionCostComponent.h"

#include "RTSResourceType.h"


URTSProductionCostComponent::URTSProductionCostComponent(const FObjectInitializer& ObjectInitializer)
{
	RefundFactor = 0.5f;
}
