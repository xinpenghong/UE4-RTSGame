#include "RTSPluginPCH.h"
#include "RTSCameraBoundsVolume.h"


ARTSCameraBoundsVolume::ARTSCameraBoundsVolume(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
{
}
