#include "RTSPluginPCH.h"
#include "RTSPortraitComponent.h"

#include "Engine/Texture2D.h"
